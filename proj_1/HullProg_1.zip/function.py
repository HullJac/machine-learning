import numpy as np

#def F(x, y):
#    return 2*x**2 + 3*y**2 - 12*x - 6*y + 9

def F(x,y):
    return 5*x**2 + 2*y**2    
'''
def F(x,y):
    t1 = .01*x**2 + 0.01*y**2
    t2 = np.exp(-x**2-y**2)
    t3 = -.5*np.exp(-(x-2)**2-(y-2)**2)
    t4 = -.75*np.exp(-(x+2)**2-(y-2)**2)

    return t1 + t2 + t3 + t4
    '''
