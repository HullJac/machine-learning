'''
Program:    2-d Gradient Descent
Programmer: Jacob Hull
Date:       9/15/21
Overview:   This program will take a two dimensional function that is provided by the user and 
            by using graident descent will find the global minimum of that function.
'''
import numpy as np
import matplotlib.pyplot as plt
from function import F
import time

def main(seed, f):
    delta = 10
    eta = .00001
    
    maxSteps = 18000
    cost = np.empty(maxSteps)
    
    # Setting the seed
    randomSeed = 2000
    np.random.seed(randomSeed)
    
    # Get a random (x, y)
    position = np.random.sample(2)*100-50
    #f.write("start: " + str(position) + "\n")

    sigma = F(position[0], position[1])

    # Will be 0,1,or 2
    dSigma = np.random.randint(3)
    #print("dSigma: {}".format(dSigma))
    
    tempPosition = position + delta * (-1) ** dSigma 
    
    tempSigma = F(tempPosition[0], tempPosition[1])
    
    #print("position: {}\ntempPosition: {}\nsigma: {}\ntempSigma: {}".format(position, tempPosition, sigma, tempSigma))
    
    for i in range(maxSteps):
        cost[i] = sigma
        #print(cost[i]) 
        
        # Info to preserve to use next time in the loop
        holdx = position[0]
        holdy = position[1]
        #holdPosition = position
        #print("holdPosition: {}, {}".format(holdx, holdy))

        # This line is the meat of gradient decent
        position[0] = position[0] - eta * (-sigma + tempSigma)/np.abs(position[0] - tempPosition[0]) 
        position[1] = position[1] - eta * (-sigma + tempSigma)/np.abs(position[1] - tempPosition[1]) 
        #position = position - eta * (-sigma + tempSigma)/np.abs(position - tempPosition) 
        #print("pos after calc: {}, {}".format(position[0], position[1]))

        tempSigma = sigma
        sigma = F(position[0], position[1])
        # The old position to use next time in the loop
        tempPosition[0] = holdx
        tempPosition[1] = holdy
        #tempPosition = holdPosition
        #print("tempPosition: {}, {}".format(tempPosition[0], tempPosition[1]))
        #time.sleep(.01)

    fig, graph=plt.subplots()
    graph.plot(cost)

    plt.show()
    print(position)

    #f.write("end: " + str(position) + "\n")

if __name__ == "__main__":
    f = open("out.txt", "w")
    for i in range(1):
        #print("-------------------{}--------------------".format(i))
        main(i, f)
    f.close()
